import argparse
import numpy as np
import torch
import os
import scipy.io as sio
import pickle
from torch.utils.data import DataLoader
from io_utils import EmotionDataset
from load_data import load_srt_raw_newPre
from train_utils import train_earlyStopping
from modules import *
import torch.nn as nn
import torch.nn.functional as F
from model import stratified_layerNorm
import random
from scipy.signal.windows import hann


parser = argparse.ArgumentParser(description='Finetune the pretrained model for EEG emotion recognition')
parser.add_argument('--gpu-index', default=0, type=int, help='Gpu index.')
parser.add_argument('--timeLen', default=5, type=int,
                    help='time length in seconds')
parser.add_argument('--learning-rate', default=0.0007, type=float, metavar='LR',
                    help='learning rate')
parser.add_argument('--weight-decay', default=0.015, type=float,
                    metavar='W', help='weight decay (default: 0.05)',
                    dest='weight_decay')
parser.add_argument('--randSeed', default=7, type=int,
                    help='random seed')
parser.add_argument('--timeFilterLen', default=60, type=int,
                    help='time filter length')
parser.add_argument('--n_spatialFilters', default=16, type=int,
                    help='time filter length')
parser.add_argument('--n_timeFilters', default=16, type=int,
                    help='time filter length')
parser.add_argument('--multiFact', default=2, type=int,
                    help='time filter length')
parser.add_argument('--normTrain', default='yes', type=str,
                    help='whether normTrain')
parser.add_argument('--use-data', default='pretrained', type=str,
                    help='use which pretrained model')
# parser.add_argument('--cls', default=9, type=int,
#                     help='how many cls to use')
parser.add_argument('--dataset', default='both', type=str,
                    help='first or second')
parser.add_argument('--temperature', default=0.07, type=float,
                    help='softmax temperature (default: 0.07)')

args = parser.parse_args()

random.seed(args.randSeed)
np.random.seed(args.randSeed)
torch.manual_seed(args.randSeed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

torch.set_num_threads(8)
args.device = torch.device('cuda')



dataset = args.dataset

n_subs = 80

timeLen = 1
timeStep = 1
fs = 250
channel_norm = False
time_norm = False
data_len = fs * timeLen

n_spatialFilters = args.n_spatialFilters
n_timeFilters = args.n_timeFilters
timeFilterLen = args.timeFilterLen
n_channs = 30
multiFact = 2

randomInit = False
stratified = []

data_dir = './'

save_dir = data_dir + 'runs_srt/raw_24video_batch28_dataset_%s_timeLen5_tf16_sf16_multiFact2_lr0.000700_wd0.015000_epochs100_randSeed%d_fold10_accSel_newPre_2' % (
    args.dataset, args.randSeed)

print(save_dir)


class ConvNet_baseNonlinearHead(nn.Module):
    def __init__(self, n_spatialFilters, n_timeFilters, timeFilterLen, n_channs, stratified, multiFact):
        super(ConvNet_baseNonlinearHead, self).__init__()
        self.spatialConv = nn.Conv2d(1, n_spatialFilters, (n_channs, 1))
        self.timeConv = nn.Conv2d(1, n_timeFilters, (1, timeFilterLen), padding=(0, (timeFilterLen-1)//2))
        self.avgpool = nn.AvgPool2d((1, 30))
        self.CBAM = CBAM(n_timeFilters)
        self.spatialConv2 = nn.Conv2d(n_timeFilters, n_timeFilters*multiFact, (n_spatialFilters, 1), groups=n_timeFilters)
        self.timeConv2 = nn.Conv2d(n_timeFilters*multiFact, n_timeFilters*multiFact*multiFact, (1, 6), groups=n_timeFilters*multiFact)
        self.ECA2 = ECA(n_timeFilters * multiFact * multiFact)
        self.n_spatialFilters = n_spatialFilters
        self.n_timeFilters = n_timeFilters
        self.stratified = stratified

    def forward(self, input):
        # print(input.shape)
        if 'initial' in self.stratified:
            input = stratified_layerNorm(input, input.shape[0])

        out = self.spatialConv(input)
        out = out.permute(0,2,1,3)
        out = self.timeConv(out)
        out1 = out.clone()
        out = self.CBAM(out)
        out = F.elu(out)
        out = self.avgpool(out)

        if 'middle1' in self.stratified:
            out = stratified_layerNorm(out, out.shape[0])

        out = F.elu(self.spatialConv2(out))
        out = self.timeConv2(out)
        out = self.ECA2(out)
        out = F.elu(out)

        if 'middle2' in self.stratified:
            out = stratified_layerNorm(out, out.shape[0])
        return out, out1

data, label_repeat, n_samples, n_segs = load_srt_raw_newPre(timeLen, timeStep, fs, channel_norm, time_norm)
torch.cuda.set_device(args.gpu_index)

n_total = int(np.sum(n_samples))
print('n_total', n_total)
print('n_samples', n_samples)
print('n_segs', n_segs)

bn = 1

n_subs = 80

n_folds = 10
#
n_per = round(n_subs / n_folds)

for fold in range(n_folds):
    features1_de = np.zeros((n_subs, n_total, n_timeFilters, n_spatialFilters))
    print('fold', fold)

    model = ConvNet_baseNonlinearHead(n_spatialFilters, n_timeFilters, timeFilterLen, n_channs, stratified, multiFact).to(args.device)
    print(model)
    para_num = sum([p.data.nelement() for p in model.parameters()])
    print('Total number of parameters:', para_num)

    if not randomInit:
        if args.dataset in ['both']:
            with open(os.path.join(save_dir, 'folds_' + 'all' + '_dataset_both_results_pretrain.pkl'), 'rb') as f:
                results_pretrain = pickle.load(f)
            best_pretrain_epoch = int(results_pretrain['best_epoch'][fold])
            checkpoint_name = 'checkpoint_{:04d}.pth.tar'.format(best_pretrain_epoch)
            print('load:', checkpoint_name)
            checkpoint = torch.load(os.path.join(save_dir, str(fold), checkpoint_name), map_location=args.device)
        state_dict = checkpoint['state_dict']
        model.load_state_dict(state_dict, strict=False)

    if fold < n_folds-1:
        val_sub = np.arange(n_per*fold, n_per*(fold+1))
    else:
        # val_sub = np.arange(n_per*fold, n_per*(fold+1)-1)
        val_sub = np.arange(n_per * fold, n_subs)

    val_sub = [int(val) for val in val_sub]
    print('val', val_sub)
    train_sub = list(set(np.arange(n_subs)))

    if args.normTrain == 'yes':
        print('normTrain')
        data_mean = np.mean(np.mean(data[:, :, :], axis=1), axis=0)
        data_var = np.mean(np.var(data[:, :, :], axis=1), axis=0)
        # data_mean = np.mean(np.mean(data[train_sub, :, :], axis=1), axis=0)
        # data_var = np.mean(np.var(data[train_sub, :, :], axis=1), axis=0)

        for i in range(n_subs):
            data[i, :, :] = (data[i, :, :] - data_mean) / np.sqrt(data_var + 1e-5)
    else:
        print('Do no norm')

    val_sub = np.arange(n_subs)

    features1_de = np.zeros((len(val_sub), n_total, n_timeFilters, n_spatialFilters))
    n = 0
    for sub in val_sub:
        data_val = data[sub, :, :]
        label_val = np.array(label_repeat)
        print(sub)
        # print('data label', data_val.shape, label_val.shape)
        # Prepare data
        valset = EmotionDataset(data_val, label_val, timeLen, timeStep, n_segs, fs)
        val_loader = DataLoader(dataset=valset, batch_size=bn, pin_memory=True, num_workers=8, shuffle=False)

        isFirst = True
        for counter, (x_batch, y_batch) in enumerate(val_loader):
            x_batch = x_batch.to(args.device)
            y_batch = y_batch.to(args.device)

            _, out = model(x_batch)
            isFirst = False
            out = out.detach().cpu().numpy()

            de = 0.5 * np.log(2 * np.pi * np.exp(1) * (np.var(out, 3)))


            if (counter + 1) * bn < n_total:
                features1_de[n, counter * bn: (counter + 1) * bn, :, :] = de
            else:
                features1_de[n, counter * bn:, :, :] = de
        n = n + 1

    features1_de = features1_de.reshape(len(val_sub), n_total, 16 * 16)

    de = {'de': features1_de}
    if args.normTrain == 'yes':
        sio.savemat(os.path.join(save_dir, str(fold), 'features1_de_1s_normTrain.mat'), de)
        print(os.path.join(save_dir, str(fold), 'features1_de_1s_normTrain.mat'))
    else:
        sio.savemat(os.path.join(save_dir, str(fold), 'features1_de_1s.mat'), de)
        print(os.path.join(save_dir, str(fold), 'features1_de_1s.mat'))


    
