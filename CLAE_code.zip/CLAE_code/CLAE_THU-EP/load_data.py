import numpy as np
import scipy.io as sio
from io_utils import smooth_moving_average
import os
import h5py
import pickle


def load_srt_raw_newPre(timeLen, timeStep, fs, channel_norm, time_norm):
    n_channs = 30
    n_points = fs*30
    data_len = fs * timeLen
    n_segs = int((n_points/fs - timeLen) / timeStep + 1)
    print('n_segs:', n_segs)

    data_path = '../THU-EP_Prepro'
    data_paths = os.listdir(data_path)
    data_paths.sort()
    n_vids = 28; chn = 30; fs = 250; sec = 30;

    data = np.zeros((len(data_paths), n_vids, chn, fs * sec))

    for idx, path in enumerate(data_paths):
        f = open(os.path.join(data_path,path), 'rb')
        data_sub = pickle.load(f)
        data[idx,:,:,:] = data_sub[:, :, :]

    # data shape :(sub, vid, chn, fs * sec)
    print('data loaded:', data.shape)

    n_subs = data.shape[0]

    n_videos = 28

    data = np.transpose(data, (0,1,3,2)).reshape(n_subs, -1, n_channs)

    if channel_norm:
        for i in range(data.shape[0]):
            data[i,:,:] = (data[i,:,:] - np.mean(data[i,:,:], axis=0)) / np.std(data[i,:,:], axis=0)

    if time_norm:
        data = (data - np.tile(np.expand_dims(np.mean(data, axis=2), 2), (1, 1, data.shape[2]))) / np.tile(
            np.expand_dims(np.std(data, axis=2), 2), (1, 1, data.shape[2])
        )

    n_samples = np.ones(n_videos)*n_segs

    label_raw =np.array([0,0,0,1,1,1,2,2,2,3,3,3,4,4,4,4,5,5,5,6,6,6,7,7,7,8,8,8])
    label_repeat = []
    for i in range(len(label_raw)):
        label_repeat = label_repeat + [label_raw[i]]*n_segs

    return data, label_repeat, n_samples, n_segs


def load_srt_pretrainFeat(datadir, channel_norm, timeLen, timeStep, isFilt, filtLen):
    n_samples = np.ones(28).astype(np.int32) * 30

    for i in range(len(n_samples)):
        n_samples[i] = int((n_samples[i] - timeLen) / timeStep + 1)

    if datadir[-4:] == '.npy':
        data = np.load(datadir)
        data[data < -10] = -5
    elif datadir[-4:] == '.mat':
        data = sio.loadmat(datadir)['de_lds']
        print('isnan total:', np.sum(np.isnan(data)))
        data[np.isnan(data)] = -8
        # data[data < -8] = -8

    # data_use = data[:, np.max(data, axis=0)>1e-6]
    # data = data.reshape(45, int(np.sum(n_samples)), 256)
    print(data.shape)
    print(np.min(data), np.median(data))

    n_samples_cum = np.concatenate((np.array([0]), np.cumsum(n_samples)))
    if isFilt:
        print('filtLen', filtLen)
        data = data.transpose(0, 2, 1)
        for i in range(data.shape[0]):
            for vid in range(len(n_samples)):
                data[i, :, int(n_samples_cum[vid]): int(n_samples_cum[vid + 1])] = smooth_moving_average(data[i, :,int(n_samples_cum[ vid]): int(n_samples_cum[vid + 1])],filtLen)
        data = data.transpose(0, 2, 1)

    # Normalization for each sub
    if channel_norm:
        print('subtract mean and divided by var')
        for i in range(data.shape[0]):
            # data[i,:,:] = data[i,:,:] - np.mean(data[i,:,:], axis=0)
            data[i, :, :] = (data[i, :, :] - np.mean(data[i, :, :], axis=0)) / (np.std(data[i, :, :], axis=0) + 1e-3)

    label =np.array([0,0,0,1,1,1,2,2,2,3,3,3,4,4,4,4,5,5,5,6,6,6,7,7,7,8,8,8])
    print(label)

    label_repeat = []
    for i in range(len(label)):
        label_repeat = label_repeat + [label[i]] * n_samples[i]
    return data, label_repeat, n_samples


