import torch.nn as nn
import torch.nn.functional as F
import torch
from torch.autograd import Function
from modules import *

def stratified_norm(out, n_samples):
    n_subs = int(out.shape[0] / n_samples)
    out_str = out.clone()
    for i in range(n_subs):
        out_str[n_samples*i: n_samples*(i+1), :] = (out[n_samples*i: n_samples*(i+1), :] - out[n_samples*i: n_samples*(i+1), :].mean(
            dim=0)) / (out[n_samples*i: n_samples*(i+1), :].std(dim=0) + 1e-3)
    return out_str

def batch_norm(out):
    out_str = out.clone()
    out_str = (out - out.mean(dim=0)) / (out.std(dim=0) + 1e-3)
    return out_str

def stratified_layerNorm(out, n_samples):
    n_subs = int(out.shape[0] / n_samples)
    out_str = out.clone()
    for i in range(n_subs):
        out_oneSub = out[n_samples*i: n_samples*(i+1)]
        out_oneSub = out_oneSub.reshape(out_oneSub.shape[0], -1, out_oneSub.shape[-1]).permute(0,2,1)
        out_oneSub = out_oneSub.reshape(out_oneSub.shape[0]*out_oneSub.shape[1], -1)
        out_oneSub_str = out_oneSub.clone()
        # We don't care about the channels with very small activations
        # out_oneSub_str[:, out_oneSub.abs().sum(dim=0) > 1e-4] = (out_oneSub[:, out_oneSub.abs().sum(dim=0) > 1e-4] - out_oneSub[
        #     :, out_oneSub.abs().sum(dim=0) > 1e-4].mean(dim=0)) / (out_oneSub[:, out_oneSub.abs().sum(dim=0) > 1e-4].std(dim=0) + 1e-3)
        out_oneSub_str = (out_oneSub - out_oneSub.mean(dim=0)) / (out_oneSub.std(dim=0) + 1e-3)
        out_str[n_samples*i: n_samples*(i+1)] = out_oneSub_str.reshape(n_samples, -1, out_oneSub_str.shape[1]).permute(
            0,2,1).reshape(n_samples, out.shape[1], out.shape[2], -1)
    return out_str

def batch_layerNorm(out):
    n_samples, chn1, chn2, n_points = out.shape
    out = out.reshape(n_samples, -1, n_points).permute(0,2,1)
    out = out.reshape(n_samples*n_points, -1)
    out_str = (out - out.mean(dim=0)) / (out.std(dim=0) + 1e-3)
    out_str = out_str.reshape(n_samples, n_points, chn1*chn2).permute(
        0,2,1).reshape(n_samples, chn1, chn2, n_points)
    return out_str


class ReverseLayerF(Function):
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        output = grad_output.neg() * ctx.alpha
        return output, None

class ConvNet_baseNonlinearHead_ORI(nn.Module):
    def __init__(self, n_spatialFilters, n_timeFilters, timeFilterLen, n_channs, stratified, multiFact, isMaxPool, args):
        super(ConvNet_baseNonlinearHead_ORI, self).__init__()
        self.spatialConv = nn.Conv2d(1, n_spatialFilters, (n_channs, 1))
        self.timeConv = nn.Conv2d(1, n_timeFilters, (1, timeFilterLen), padding=(0, (timeFilterLen-1)//2))
        self.avgpool = nn.AvgPool2d((1, 30))
        self.spatialConv2 = nn.Conv2d(n_timeFilters, n_timeFilters*multiFact, (n_spatialFilters, 1), groups=n_timeFilters)
        self.timeConv2 = nn.Conv2d(n_timeFilters*multiFact, n_timeFilters*multiFact*multiFact, (1, 6), groups=n_timeFilters*multiFact)
        self.n_spatialFilters = n_spatialFilters
        self.n_timeFilters = n_timeFilters
        self.stratified = stratified
        self.isMaxPool = isMaxPool
        self.args = args
    def forward(self, input):
        # print(input.shape)
        if 'initial' in self.stratified:
            input = stratified_layerNorm(input, int(input.shape[0]/2))

        out = self.spatialConv(input)
        out = out.permute(0,2,1,3)
        out = self.timeConv(out)
        out = F.elu(out)
        out = self.avgpool(out)

        if 'middle1' in self.stratified:
            out = stratified_layerNorm(out, int(out.shape[0]/2))


        out = F.elu(self.spatialConv2(out))
        out = F.elu(self.timeConv2(out))


        if 'middle2' in self.stratified:
            out = stratified_layerNorm(out, int(out.shape[0]/2))

        if self.isMaxPool:
            # Select the dim with max average values (half of the total dims)
            _, indices = torch.topk(out.mean(dim=3), out.shape[1]//2, dim=1)
            out_pooled = torch.zeros((out.shape[0], out.shape[1]//2, out.shape[2], out.shape[3])).to(self.args.device)
            for i in range(out.shape[0]):
                out_pooled[i,:,:,:] = out[i,indices[i,:,0]]
            out_pooled = out_pooled.reshape(out_pooled.shape[0], -1)
            return out_pooled, indices
        else:
            out = out.reshape(out.shape[0], -1)
            return out

class ConvNet_baseNonlinearHead(nn.Module):
    def __init__(self, n_spatialFilters, n_timeFilters, timeFilterLen, n_channs, stratified, multiFact, isMaxPool, args):
        super(ConvNet_baseNonlinearHead, self).__init__()
        self.spatialConv = nn.Conv2d(1, n_spatialFilters, (n_channs, 1))
        self.timeConv = nn.Conv2d(1, n_timeFilters, (1, timeFilterLen), padding=(0, (timeFilterLen-1)//2))
        self.avgpool = nn.AvgPool2d((1, 30))
        self.CBAM = CBAM(n_timeFilters)
        self.spatialConv2 = nn.Conv2d(n_timeFilters, n_timeFilters*multiFact, (n_spatialFilters, 1), groups=n_timeFilters)
        self.timeConv2 = nn.Conv2d(n_timeFilters*multiFact, n_timeFilters*multiFact*multiFact, (1, 6), groups=n_timeFilters*multiFact)
        self.ECA2 = ECA(n_timeFilters * multiFact * multiFact)
        self.n_spatialFilters = n_spatialFilters
        self.n_timeFilters = n_timeFilters
        self.stratified = stratified
        self.isMaxPool = isMaxPool
        self.args = args
    def forward(self, input):
        # print(input.shape)
        if 'initial' in self.stratified:
            input = stratified_layerNorm(input, int(input.shape[0]/2))

        out = self.spatialConv(input)
        out = out.permute(0,2,1,3)
        out = self.timeConv(out)
        out = self.CBAM(out)
        out = F.elu(out)
        out = self.avgpool(out)



        if 'middle1' in self.stratified:
            out = stratified_layerNorm(out, int(out.shape[0]/2))
        out = F.elu(self.spatialConv2(out))
        out = self.timeConv2(out)
        out = self.ECA2(out)
        out = F.elu(out)
        # print(out.shape)

        if 'middle2' in self.stratified:
            out = stratified_layerNorm(out, int(out.shape[0]/2))
        # elif 'middle2_batch' in self.stratified:
        #     # out = batch_layerNorm(out)
        #     out = self.bn2(out)

        if self.isMaxPool:
            # Select the dim with max average values (half of the total dims)
            _, indices = torch.topk(out.mean(dim=3), out.shape[1]//2, dim=1)
            out_pooled = torch.zeros((out.shape[0], out.shape[1]//2, out.shape[2], out.shape[3])).to(self.args.device)
            for i in range(out.shape[0]):
                out_pooled[i,:,:,:] = out[i,indices[i,:,0]]
            out_pooled = out_pooled.reshape(out_pooled.shape[0], -1)
            return out_pooled, indices
        else:
            out = out.reshape(out.shape[0], -1)
            return out
class ConvNet_baseNonlinearHead_learnRescale(nn.Module):
    def __init__(self, n_spatialFilters, n_timeFilters, timeFilterLen, n_channs, multiFact):
        super(ConvNet_baseNonlinearHead_learnRescale, self).__init__()
        self.rescaleConv1 = nn.Conv2d(1, 1, (1, timeFilterLen))
        self.spatialConv = nn.Conv2d(1, n_spatialFilters, (n_channs, 1))
        self.timeConv = nn.Conv2d(1, n_timeFilters, (1, timeFilterLen), padding=(0, (timeFilterLen-1)//2))
        self.rescaleConv2 = nn.Conv2d(1, 1, (1, timeFilterLen))
        self.avgpool = nn.AvgPool2d((1, 24))
        # self.bn1 = nn.BatchNorm2d(n_timeFilters)
        self.spatialConv2 = nn.Conv2d(n_timeFilters, n_timeFilters*multiFact, (n_spatialFilters, 1), groups=n_timeFilters)
        self.timeConv2 = nn.Conv2d(n_timeFilters*multiFact, n_timeFilters*multiFact*multiFact, (1, 4), groups=n_timeFilters*multiFact)
        self.rescaleConv3 = nn.Conv2d(1, 1, (1, 4))
        # self.bn2 = nn.BatchNorm2d(n_timeFilters*multiFact*multiFact)
        self.n_spatialFilters = n_spatialFilters
        self.n_timeFilters = n_timeFilters
    def forward(self, input):
        out_tmp = self.rescaleConv1(input)
        out_mean = torch.mean(out_tmp, 3, True)
        out_var = torch.mean(out_tmp**2, 3, True)
        input = (input - out_mean) / torch.sqrt(out_var + 1e-5)

        out = self.spatialConv(input)
        out = out.permute(0,2,1,3)
        out = self.timeConv(out)

        out = out.reshape(out.shape[0], 1, out.shape[1]*out.shape[2], out.shape[3])
        out_tmp = self.rescaleConv2(out)
        out_mean = torch.mean(out_tmp, 3, True)
        out_var = torch.mean(out_tmp**2, 3, True)
        out = (out - out_mean) / torch.sqrt(out_var + 1e-5)
        out = out.reshape(out.shape[0], self.n_timeFilters, self.n_spatialFilters, out.shape[3])

        out = F.elu(out)
        out = self.avgpool(out)

        out = F.elu(self.spatialConv2(out))
        out = F.elu(self.timeConv2(out))

        out = out.permute(0,2,1,3)
        out_tmp = self.rescaleConv3(out)
        out_mean = torch.mean(out_tmp, 3, True)
        out_var = torch.mean(out_tmp**2, 3, True)
        out = (out - out_mean) / torch.sqrt(out_var + 1e-5)
        out = out.permute(0,2,1,3)

        out = out.reshape(out.shape[0], -1)
        return out

class simpleNN3(nn.Module):
    def __init__(self, inp_dim, hidden_dim, out_dim, n_samples, stratified):
        super(simpleNN3, self).__init__()
        self.fc1 = nn.Linear(inp_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, out_dim)
        self.n_samples = n_samples
        self.stratified = stratified
    def forward(self, input):
        if self.stratified:
            input = stratified_norm(input, self.n_samples)
        out = F.relu(self.fc1(input))
        out = F.relu(self.fc2(out))
        if self.stratified:
            out = stratified_norm(out, self.n_samples)
        out = self.fc3(out)
        return out
class Classifier(nn.Module):
    def __init__(self):
        super(Classifier, self).__init__()

        self.Classifition = nn.Sequential(
            nn.Linear(256, 32),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(32, 32),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(32, 3)
        )

    def forward(self, input):
        # input = input.contiguous().view(input.size(0), -1)
        logits = self.Classifition(input)
        return logits

class simpleNN31(nn.Module):
    def __init__(self, inp_dim, hidden_dim, out_dim, n_samples, stratified):
        super(simpleNN31, self).__init__()
        # self.SA1 = nn.Sequential(
        #     nn.Linear(inp_dim, 64),
        #     nn.ReLU(),
        #     nn.Linear(64, 64),
        # )
        # self.SA2 = nn.Sequential(
        #     nn.Linear(inp_dim, 512),
        #     nn.ReLU(),
        #     nn.Linear(512, 512),
        #     nn.ReLU(),
        #     nn.Linear(512, inp_dim),
        # )
        # self.SA2 = nn.Sequential(
        #     nn.Linear(inp_dim, 64),
        #     nn.ELU(),
        #     nn.Dropout(0.5),
        #     nn.Linear(64, inp_dim),
        # )
        self.fc1 = nn.Linear(64, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, out_dim)
        self.drop = nn.Dropout(0.5)

        # self.Projection = nn.Sequential(
        #     nn.Linear(256, 128),
        #     nn.ReLU(),
        #     nn.Linear(128, 2),
        # )

        self.n_samples = n_samples
        self.stratified = stratified
    def forward(self, input):
        if self.stratified:
            input = stratified_norm(input, self.n_samples)
        # out1 = self.SA1(input) + input
        # out2 = self.SA2(input) + input
        # out = torch.cat([out1, out2], dim=1)
        # out = self.fc(out) + input
        out = self.SA1(input)
        features = out.clone()
        # #Projection#
        # reverse_x = ReverseLayerF.apply(out, alpha)
        # domain_out = self.Projection(reverse_x)

        out = F.relu(self.fc1(out))
        out = self.drop(out)
        out = F.relu(self.fc2(out))
        out = self.drop(out)
        if self.stratified:
            out = stratified_norm(out, self.n_samples)
        labels = self.fc3(out)
        return labels, features


class MY_simpleNN3(nn.Module):
    def __init__(self, out_dim, n_samples, stratified):
        super(MY_simpleNN3, self).__init__()
        # self.FeatureLayer1 = nn.Sequential(
        #     nn.Conv1d(1,9, kernel_size=3, groups=1, padding=(3 - 1) // 2),
        #     # nn.BatchNorm1d(9),
        #     # nn.ReLU(),
        # )
        # # self.FeatureLayer2 = nn.Sequential(
        # #     nn.Conv1d(1,9, kernel_size=5, groups=1, padding=(5 - 1) // 2),
        # #     # nn.BatchNorm1d(9),
        # #     # nn.ReLU(),
        # # )
        # self.FeatureLayer3 = nn.Sequential(
        #     nn.Conv1d(1,9, kernel_size=5, groups=1, padding=(5 - 1) // 2),
        #     # nn.BatchNorm1d(9),
        #     # nn.ReLU(),
        # )
        # self.Fusion = nn.Conv1d(18,1, kernel_size=1, padding=(1-1)//2)
        # self.Norm = nn.BatchNorm1d(1)
        # self.flatten = nn.Flatten()
        # self.linear = nn.Linear(256, 256)
        self.n_samples = n_samples
        self.stratified = stratified

        self.Classifier = nn.Sequential(
            nn.Linear(256, 128),
            # nn.LayerNorm(128),
            nn.ELU(),
            nn.Dropout(0.5),
            nn.Linear(128, 64),
            # nn.LayerNorm(64),
            nn.ELU(),
            nn.Dropout(0.5),
            nn.Linear(64, out_dim),
        )

        # self.DomainClassifier = nn.Sequential(
        #     nn.Linear(256, 32),
        #     nn.ReLU(),
        #     # # nn.Linear(512, 256),
        #     # # nn.ReLU(),
        #     # # nn.Dropout(0.5),
        #     nn.Linear(32, 2),
        # )


    def forward(self, input):

        # out = input.unsqueeze(1)
        # out1 = self.FeatureLayer1(out)
        # # out2 = self.FeatureLayer2(out)
        # out3 = self.FeatureLayer3(out)
        # out_cat = torch.cat([out1, out3], dim=1)
        # out = F.relu(self.Fusion(out_cat) + out)
        # out = self.flatten(out)
        # # out = self.linear(out)
        # feature = out.clone()
        label_out = self.Classifier(input)

        # reverse_x = ReverseLayerF.apply(out, alpha)
        # domain_out = self.DomainClassifier(reverse_x)

        # if self.stratified:
        #     out = stratified_norm(out, self.n_samples)
        # out = self.fc3(out)
        return  label_out

class LSTM_NN(nn.Module):
    def __init__(self, inp_dim, hidden_dim, out_dim, n_samples, stratified):
        super(LSTM_NN, self).__init__()
        self.lstm = nn.LSTM(inp_dim, hidden_dim, batch_first=True)
        self.fc1 = nn.Linear(inp_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, out_dim)
        self.n_samples = n_samples
        self.stratified = stratified
    def forward(self, input):
        # input: (batch, seq, features)
        input, _ = self.lstm(input)
        input = input.reshape(input.shape[0]*input.shape[1], -1)
        if self.stratified:
            input = stratified_norm(input, self.n_samples)
        out = F.relu(self.fc1(input))
        out = F.relu(self.fc2(out))
        if self.stratified:
            out = stratified_norm(out, self.n_samples)
        out = self.fc3(out)
        return out