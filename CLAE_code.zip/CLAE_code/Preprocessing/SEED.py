import os
import numpy as np
import math
import matplotlib.pyplot as plt
from glob import glob

import pandas as pd
import scipy.io
import scipy.io as sio
from Preprocessing_seed import *
from mne.io.constants import CHANNEL_LOC_ALIASES
import hdf5storage
import argparse
import copy

# parser = argparse.ArgumentParser(description='whether to implement clisa')
# parser.add_argument('--clisa-or-not', default='', type=str,
#                     help='implement the clisa preprocessing step, yes or no')
# args = parser.parse_args()
# clisa_or_not = args.clisa_or_not


if __name__ == '__main__':

    data_dir = '../SEED/session1'

    channel_info = pd.read_excel('./channel_order.xlsx')  # 替换为你的 .xlsx 文件路径
    channel_info = channel_info[~channel_info['name'].isin(['CB1', 'CB2'])]
    channel_names = channel_info['name'].tolist()
    sfreq = 200  # 采样率为 200 Hz
    sorted_file = sorted(os.listdir(data_dir), key=lambda x: int(x[3:5]))
    # Read the data
    for sub in sorted_file:
        eeg_clisa = None
        sub_path = os.path.join(data_dir, sub)
        print("Current processing subject:", sub[0:5])
        mat_data = sio.loadmat(sub_path)
        # 遍历 .mat 文件中的每个键
        for key in mat_data:
            # 排除 MATLAB 文件的默认键，例如 '__header__', '__version__', '__globals__'
            if not key.startswith('__'):
                print(f"矩阵名: {key}")
                eeg_data_raw = mat_data[key]
                eeg_data = np.delete(eeg_data_raw, [-1, -5], axis=0)
                scipy.io.savemat('ori_data.mat', {'data':eeg_data})
                info = mne.create_info(ch_names=channel_names, sfreq=sfreq, ch_types=['eeg' for _ in range(60)])
                raw = mne.io.RawArray(eeg_data, info)
                raw.plot(n_channels=len(channel_names), scalings='auto', title='ORI EEG', show=True)
                plt.plot()

                processed_epoch_clisa = Preprocessing_seed(raw, 'SEED')
                processed_epoch_clisa.band_pass_filter(0.05, 47)
                processed_epoch_clisa.bad_channels_interpolate(thresh1=3, proportion=0.5)
                processed_epoch_clisa.eeg_ica()
                processed_epoch_clisa.band_pass_filter(4, 47)
                processed_epoch_clisa.average_ref()

                scipy.io.savemat('pro_data.mat',{'data':processed_epoch_clisa.raw.get_data()})
                raw.plot(n_channels=len(channel_names), scalings='auto', title='Process EEG', show=True)

                eeg_clisa=data_concat(eeg_clisa, processed_epoch_clisa.raw.get_data())

        f = open('../SEED_Prepro/' + sub[0:5] +'.pkl','wb')
        pkl.dump(eeg_clisa,f)
        f.close()




