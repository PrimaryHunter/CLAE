import os

import h5py
import numpy as np
import math
import matplotlib.pyplot as plt
from glob import glob

import pandas as pd
import scipy.io
import scipy.io as sio
from Preprocessing_thu import *
from mne.io.constants import CHANNEL_LOC_ALIASES
import hdf5storage
import argparse
import copy

# parser = argparse.ArgumentParser(description='whether to implement clisa')
# parser.add_argument('--clisa-or-not', default='', type=str,
#                     help='implement the clisa preprocessing step, yes or no')
# args = parser.parse_args()
# clisa_or_not = args.clisa_or_not


if __name__ == '__main__':

    data_dir = '../THU-EP'

    channel_info = pd.read_excel('./channel_order.xlsx')  # 替换为你的 .xlsx 文件路径
    channel_info = channel_info[~channel_info['name'].isin(['A1', 'A2'])]
    channel_names = channel_info['name'].tolist()
    sfreq = 250  # 采样率为 250 Hz
    sorted_file = sorted(os.listdir(data_dir), key=lambda x: int(x[4:6]))
    # Read the data
    for sub in sorted_file:
        eeg_clisa = None
        sub_path = os.path.join(data_dir, sub)
        print("Current processing subject:", sub[0:6])
        with h5py.File(sub_path, 'r') as f:
            data = f['data'][()]
        data = data.T
        data = data[5,:,:,:]
        for vidio in range (0,28):
            eeg_data_raw = data[vidio,:,:]
            eeg_data = np.delete(eeg_data_raw, [16, 17], axis=0)
            info = mne.create_info(ch_names=channel_names, sfreq=sfreq, ch_types=['eeg' for _ in range(30)])
            raw = mne.io.RawArray(eeg_data, info)


            processed_epoch_clisa = Preprocessing_thu(raw, 'THU_EP')
            processed_epoch_clisa.band_pass_filter(0.05, 47)
            processed_epoch_clisa.bad_channels_interpolate(thresh1=3, proportion=0.5)
            processed_epoch_clisa.eeg_ica()
            processed_epoch_clisa.band_pass_filter(4, 47)
            processed_epoch_clisa.average_ref()


            eeg_clisa=data_concat(eeg_clisa, processed_epoch_clisa.raw.get_data())

        f = open('../THU-EP_Prepro/' + sub[0:6] +'.pkl','wb')
        pkl.dump(eeg_clisa,f)
        f.close()